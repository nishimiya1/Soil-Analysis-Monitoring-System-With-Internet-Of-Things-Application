package com.example.soilmonitoring;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Home extends AppCompatActivity {
    TextView tempvalue, soilTempValue, soilMoistValue, humidityValue;
    DatabaseReference reference;
    String status;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        soilTempValue = (TextView)findViewById(R.id.soiltempValue);
        soilMoistValue = (TextView)findViewById(R.id.soilmoistValue);
        tempvalue = (TextView) findViewById(R.id.tempValue);
        humidityValue = (TextView) findViewById(R.id.humidValue);

        reference = FirebaseDatabase.getInstance().getReference();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                status = snapshot.child("Soil Temperatue").getValue().toString();
                soilTempValue.setText(status);
                status = snapshot.child("Soil Moisture").getValue().toString();
                soilMoistValue.setText(status);
                status = snapshot.child("Temperatue").getValue().toString();
                tempvalue.setText(status);
                status = snapshot.child("Humidity").getValue().toString();
                humidityValue.setText(status);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }
}